package com.zjm.springboot.controller;

import com.zjm.springboot.entity.User;
import com.zjm.springboot.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

/**
 * @description:
 * @Author:zjm
 * @Date:2020/3/8 16:15
 */
@RestController
public class UserController {

    @Autowired
    UserRepository repository;

    @GetMapping("/user/{id}")
    public Object getUser(@PathVariable("id") Integer id){
        Optional<User> user = repository.findById(id);
        return user;
    }

    @GetMapping("/user")
    public User addUser(User user){
        User user1 = repository.save(user);
        return user1;
    }
}
