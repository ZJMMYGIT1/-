package com.zjm.springboot.repository;

import com.zjm.springboot.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @description:
 * @Author:zjm
 * @Date:2020/3/7 14:42
 */
//继承JpaRepository<User,Integer>来完成数据库操作<操作得类，类得主键>
public interface UserRepository extends JpaRepository<User,Integer> {

}
