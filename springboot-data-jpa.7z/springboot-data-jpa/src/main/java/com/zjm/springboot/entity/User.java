package com.zjm.springboot.entity;

import javax.persistence.*;

/**
 * @description:
 * @Author:zjm
 * @Date:2020/3/7 14:34
 */
//使用jpa注解配置映射关系
@Entity //告诉jpa这是一个实体类
@Table(name = "tbl_name") //@Table来指定和哪个数据表对应
public class User {
    @Id //这是主键
    @GeneratedValue(strategy = GenerationType.IDENTITY)//设置自增
    private Integer id;
    @Column(name = "last_name",length = 50)//设置与属性对应得列
    private String lastName;
    @Column //省略默认就是属性名
    private String email;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
